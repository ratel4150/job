import writePermissionSchemaUser from "./users/writePermissionSchemaUser.js";
import readPermissionSchemaUser from "./users/readPermissionSchemaUser.js";
export default readPermissionSchemaUser