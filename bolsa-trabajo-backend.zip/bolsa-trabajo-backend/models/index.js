//model/index.js

import  User  from "./user/User.js"
import UserProfile from "./user/UserProfile.js"

export default {User, UserProfile}