import authMiddleware from './authMiddleware/authMiddleware.js'
console.log(authMiddleware);
export default authMiddleware